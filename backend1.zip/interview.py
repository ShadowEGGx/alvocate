import openai
import os
from flask import request, jsonify
from database import interviews_collection
from dotenv import load_dotenv

# Load API keys from .env
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

openai.api_key = OPENAI_API_KEY

# Function to generate interview questions
import openai

def generate_question():
    client = openai.OpenAI()  # ✅ Initialize OpenAI Client
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "system", "content": "Generate a CSE job interview question"}]
    )
    return response.choices[0].message.content


# Function to store user answers
def store_answer(data):
    data = request.json
    username = data.get("username")
    question = data.get("question")
    user_answer = data.get("user_answer")
    correct_answer = data.get("correct_answer")  # AI can provide the expected answer
    time_taken = data.get("time_taken")

    interviews_collection.insert_one({
        "username": username,
        "question": question,
        "user_answer": user_answer,
        "correct_answer": correct_answer,
        "time_taken": time_taken
    })

    return jsonify({"message": "Answer stored successfully"})
