from flask import Flask, request, jsonify
from flask_cors import CORS 
from auth import register, login, verify_token
from interview import generate_question, store_answer

app = Flask(__name__)
CORS(app)

@app.route("/")
def home():
    return jsonify({"message": "Welcome to Alvocate Interview API!"})

# Authentication Routes
@app.route("/register", methods=["POST"])
def register_user():
    data = request.get_json()  # ✅ Get JSON from request
    return register(data)  # ✅ Pass data to register()

@app.route("/login", methods=["POST"])
def login_user():
    data = request.get_json()  # ✅ Get JSON from request
    return login(data)  # ✅ Pass data to login()

# Interview Routes
@app.route("/generate_question", methods=["GET"])
def get_question():
    return generate_question()

@app.route("/submit_answer", methods=["POST"])
def submit_answer():
    data = request.get_json()  # ✅ Get JSON from request
    return store_answer(data)  # ✅ Pass data to store_answer()

if __name__ == "__main__":
    print("Registered Routes:", app.url_map)
    app.run(debug=True)  # Debug mode for development
