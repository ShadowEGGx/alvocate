try:
    from pymongo import MongoClient
except ModuleNotFoundError:
    raise ImportError("pymongo is not installed. Install it using 'pip install pymongo'.")

import os
from dotenv import load_dotenv
import bcrypt

# Load environment variables
load_dotenv()

# Get MongoDB URI from .env (Use your Atlas connection)
MONGO_URI = os.getenv("MONGO_URI")

# Connect to MongoDB Atlas
try:
    client = MongoClient(MONGO_URI)
    db = client["interview_chatbot"]  # Make sure this database exists in your Atlas cluster
    print("✅ Successfully connected to MongoDB Atlas!")
except Exception as e:
    print(f"❌ Failed to connect to MongoDB Atlas: {e}")
    raise ConnectionError("Could not connect to MongoDB. Check your MONGO_URI in .env.")

# Collections for storing users and interview results
users_collection = db["users"]
interviews_collection = db["interviews"]

# Function to add a user with password hashing
def add_user(username, password):
    if users_collection.find_one({"username": username}):
        return {"error": "User already exists"}
    hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())
    users_collection.insert_one({"username": username, "password": hashed_password.decode("utf-8")})
    return {"message": "User added successfully"}

# Function to store interview results
def store_interview_result(username, question, user_answer, correct_answer, time_taken):
    interviews_collection.insert_one({
        "username": username,
        "question": question,
        "user_answer": user_answer,
        "correct_answer": correct_answer,
        "time_taken": time_taken
    })

print("✅ MongoDB Database initialized and ready!")
