import jwt
import datetime
import os
import bcrypt
from flask import request, jsonify
from database import users_collection
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
SECRET_KEY = os.getenv("SECRET_KEY", "default_secret_key")

# Function to register a user
def register(data):  # Accept data from app.py
    try:
        username = data.get("username")
        password = data.get("password")

        if not username or not password:
            return jsonify({"error": "Username and password are required"}), 400

        if users_collection.find_one({"username": username}):
            return jsonify({"error": "User already exists"}), 400

        hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())
        users_collection.insert_one({"username": username, "password": hashed_password.decode("utf-8")})

        return jsonify({"message": "User added successfully"}), 201

    except Exception as e:
        print(f"❌ Error in register function: {e}")  # Debugging output
        return jsonify({"error": "Internal server error"}), 500

# Function to login and generate JWT token
def login(data):  # Accept data from app.py
    try:
        username = data.get("username")
        password = data.get("password")

        user = users_collection.find_one({"username": username})
        if not user or not bcrypt.checkpw(password.encode("utf-8"), user["password"].encode("utf-8")):
            return jsonify({"error": "Invalid username or password"}), 401

        token = jwt.encode(
            {"username": username, "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1)},
            SECRET_KEY,
            algorithm="HS256"
        )

        return jsonify({"token": token})

    except Exception as e:
        print(f"❌ Error in login function: {e}")  # Debugging output
        return jsonify({"error": "Internal server error"}), 500

# Function to verify JWT token
def verify_token(token):
    try:
        decoded = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return decoded["username"]
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None
